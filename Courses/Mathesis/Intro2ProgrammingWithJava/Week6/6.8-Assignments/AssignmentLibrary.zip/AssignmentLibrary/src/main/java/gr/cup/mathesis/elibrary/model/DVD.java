package gr.cup.mathesis.elibrary.model;

/**
 * A DVD that contains one or more movies.
 * 
 * TODO: 1. Implement this class
 *
 * @author mathesis
 */
public final class DVD {

    public enum Genre {
        UNCATEGORIZED, ACTION, COMEDY, DOCUMENTARY, DRAMA, FANTASY, HORROR, ROMANCE, SCIFI, THRILLER;
    }
    
    /** First DVD. */
    public static final int MIN_PUB_YEAR = 1996;

}
