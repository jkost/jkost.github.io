package gr.ubuntistas.issue10;

import java.io.UnsupportedEncodingException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.SecureRandom;
import java.security.Security;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.KeyGenerator;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

import org.bouncycastle.jce.provider.BouncyCastleProvider;
/**
 * Encrypts and then decrypts a message from the standard input using 
 * public key encryption to encrypt and send the key, and then symmetric
 * encryption to encrypt the message.
 * @author hawk
 * @date 
 */
public class CombinedSymmetricASymmetricExample {
	private KeyPair keypair;  								// public/private key pair
	private SecretKey key;									// secret symmetric key 
	private Cipher symmetricCipher, asymmetricCipher;		// ciphers to use
	private static final int KEYSIZE = 1024; 				// PKI key size
	private static final String SYMMETRIC_ALGORITHM = "AES/ECB/PKCS7Padding";
	private static final String ASYMMETRIC_ALGORITHM = "RSA/NONE/OAEPWithSHA1AndMGF1Padding";
	
	/**
	 * Initializes the encryption algorithms
	 * @param symmetricAlgorithm symmetric algorithm to use, e.g. 'DES', 'AES' etc.
	 * @param asymmetricAlgorithm asymmetric algorithm to use, e.g. 'RSA', 'ElGamal' etc.
	 * @param provider provider to use, e.g. 'BC' for BouncyCastle
	 * @throws NoSuchAlgorithmException if algorithm does not exist
	 * @throws NoSuchPaddingException
	 * @throws NoSuchProviderException 
	 */
	CombinedSymmetricASymmetricExample(final String symmetricAlgorithm, final String asymmetricAlgorithm, final String provider) throws NoSuchAlgorithmException, NoSuchPaddingException, NoSuchProviderException {
		key = generateKey(symmetricAlgorithm.indexOf('/') == -1 ? symmetricAlgorithm : symmetricAlgorithm.substring(0, symmetricAlgorithm.indexOf('/')));
		symmetricCipher = Cipher.getInstance(symmetricAlgorithm, provider);	
		
		keypair = generateKeyPair(asymmetricAlgorithm.indexOf('/') == -1 ? asymmetricAlgorithm : asymmetricAlgorithm.substring(0, asymmetricAlgorithm.indexOf('/')), provider);
		asymmetricCipher = Cipher.getInstance(asymmetricAlgorithm, provider);	
	}
	
	/**
	 * Generates a random secret key.
	 * @param algorithm to use, e.g. DES, AES etc.
	 * @throws NoSuchAlgorithmException if the algorithm string passed as a parameter is not recognized
	 */
	private SecretKey generateKey(final String algorithm) throws NoSuchAlgorithmException {
		KeyGenerator keygen = KeyGenerator.getInstance(algorithm);
		keygen.init(new SecureRandom());
		return keygen.generateKey();
	}
	
	/**
	 * Generates a random secret key pair (i.e. a public/private key pair).
	 * @param algorithm algorithm to use, e.g. 'RSA', 'ElGamal', 'DH' etc.
	 * @param provider provider to use, e.g. 'BC' for BouncyCastle
	 * @throws NoSuchAlgorithmException if the algorithm string passed as a parameter is not recognized
	 * @throws NoSuchProviderException 
	 */
	private KeyPair generateKeyPair(final String algorithm, final String provider) throws NoSuchAlgorithmException, NoSuchProviderException {
		KeyPairGenerator keypairgenerator = KeyPairGenerator.getInstance(algorithm, provider);
		keypairgenerator.initialize(KEYSIZE, new SecureRandom());
		KeyPair keyPair = keypairgenerator.generateKeyPair();
		return keyPair;
	}
	
	/**
	 * Encrypts the <code>message</code> using the public or secret key.
	 * @param message plain text message to be encrypted
	 * @param cipher cipher to use (symmetric or asymmetric)
	 * @param key key to use for encryption (symmetric or public)
	 * @return the encrypted message
	 * @throws UnsupportedEncodingException if encoding is not UTF-8 
	 * @throws InvalidKeyException 
	 * @throws BadPaddingException 
	 * @throws IllegalBlockSizeException 
	 */
	byte[] encrypt(final byte[] message, final Cipher cipher, final Key key) throws InvalidKeyException, IllegalBlockSizeException, BadPaddingException {
		byte[] cipherText = new byte[message.length];
		cipher.init(Cipher.ENCRYPT_MODE, key);
		cipherText = cipher.doFinal(message);
		return cipherText;
	}
	/**
	 * Decrypts the <code>cipherText</code> using the private or secret key.
	 * @param cipherText cipher text 
	 * @param cipher cipher to use (symmetric or asymmetric)
	 * @param key key to use for decryption (symmetric or private)
	 * @return the decrypted message
	 * @throws UnsupportedEncodingException if encoding is not UTF-8
	 * @throws InvalidKeyException 
	 * @throws IllegalBlockSizeException
	 * @throws BadPaddingException
	 * @throws InvalidAlgorithmParameterException 
	 */
	byte[] decrypt(final byte[] cipherText, final Cipher cipher, final Key key) throws InvalidKeyException, IllegalBlockSizeException, BadPaddingException {
		byte[] plainText = new byte[cipherText.length];
		cipher.init(Cipher.DECRYPT_MODE, key);
		plainText = cipher.doFinal(cipherText);
		return plainText;
	}

	/**
	 * @return the keypair
	 */
	KeyPair getKeypair() {
		return keypair;
	}

	/**
	 * @return the key
	 */
	SecretKey getKey() {
		return key;
	}

	/**
	 * @return the symmetricCipher
	 */
	Cipher getSymmetricCipher() {
		return symmetricCipher;
	}

	/**
	 * @return the asymmetricCipher
	 */
	Cipher getAsymmetricCipher() {
		return asymmetricCipher;
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) throws Exception {
		String message="";
		if (args.length > 0) {
			for (int i=0; i<args.length; i++)
				message += args[i]+" ";
		} else {
			System.out.println("Usage: java -cp .:../lib/bcprov-jdk16-145.jar gr.ubuntistas.issue10.CombinedSymmetricASymmetricExample <plain text>");
			System.exit(1);
		}
		Security.addProvider(new BouncyCastleProvider());
		
		System.out.println("Plain text input: " + message);
		
		CombinedSymmetricASymmetricExample combined = new CombinedSymmetricASymmetricExample(SYMMETRIC_ALGORITHM, ASYMMETRIC_ALGORITHM, "BC");
		
		// encrypt the secret key with the public key
		byte[] encryptedSecretKey = combined.encrypt(combined.getKey().getEncoded(), combined.getAsymmetricCipher(), combined.getKeypair().getPublic());
		System.out.println("Encrypted secret key: " + encryptedSecretKey);
		
		// encrypt the message with the secret symmetric key
		byte[] cipherText = combined.encrypt(message.getBytes("UTF-8"), combined.getSymmetricCipher(), combined.getKey());
		System.out.println("Cipher text: " + cipherText);

		// decrypt the secret key with the private key
		Key recoveredSecretKey = new SecretKeySpec(combined.decrypt(encryptedSecretKey, combined.getAsymmetricCipher(), combined.getKeypair().getPrivate()), SYMMETRIC_ALGORITHM);
		System.out.println("Recovered secret key: " + recoveredSecretKey.getEncoded());
		
		// decrypt the message with the secret key
		System.out.println("Plain text output: " + new String(combined.decrypt(cipherText, combined.getSymmetricCipher(), recoveredSecretKey), "UTF-8"));
		
	}

}
