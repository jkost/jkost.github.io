package gr.ubuntistas.issue10;

import java.io.UnsupportedEncodingException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.SecureRandom;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.KeyAgreement;
import javax.crypto.NoSuchPaddingException;

import org.apache.commons.codec.binary.Base64;
/**
 * Encrypts and then decrypts a message from the standard input using 
 * public key encryption.
 * @author hawk
 * @date 
 */
public class SimpleASymmetricExample {
	private KeyPair keypair;  	// public/private key pair
	private Cipher cipher;		// cipher being used
	private static final int KEYSIZE = 1024; // PKI key size
	
	/**
	 * Initializes the asymmetric encryption algorithm
	 * @param algorithm to use, e.g. 'RSA', 'ElGamal', 'DH' etc.
	 * @throws NoSuchAlgorithmException if algorithm does not exist
	 * @throws NoSuchPaddingException
	 * @throws NoSuchProviderException 
	 */
	SimpleASymmetricExample(final String algorithm) throws NoSuchAlgorithmException, NoSuchPaddingException, NoSuchProviderException {
		keypair = generateKeyPair(algorithm);
		cipher = Cipher.getInstance(algorithm);	
	}
	
	/**
	 * Generates a random secret key pair (i.e. a public/private key pair).
	 * @param algorithm to use, e.g. 'RSA', 'ElGamal', 'DH' etc.
	 * @throws NoSuchAlgorithmException if the algorithm string passed as a parameter is not recognized
	 */
	private KeyPair generateKeyPair(final String algorithm) throws NoSuchAlgorithmException {
		KeyPairGenerator keypairgenerator = KeyPairGenerator.getInstance(algorithm);
		keypairgenerator.initialize(KEYSIZE, new SecureRandom());
		KeyPair keyPair = keypairgenerator.generateKeyPair();
		return keyPair;
	}
	
	/**
	 * Encrypts the <code>message</code> using the public key.
	 * @param message plain text message to be encrypted
	 * @return a base64 encoded representation of the encrypted message
	 * @throws UnsupportedEncodingException if encoding is not UTF-8 
	 * @throws InvalidKeyException 
	 * @throws BadPaddingException 
	 * @throws IllegalBlockSizeException 
	 */
	String encrypt(final String message) throws UnsupportedEncodingException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException {
		byte[] plainText = message.getBytes("UTF-8");
		byte[] cipherText = new byte[plainText.length];
		cipher.init(Cipher.ENCRYPT_MODE, keypair.getPublic()); //, new SecureRandom());
		cipherText = cipher.doFinal(plainText);
		Base64 encoder = new Base64();
		return encoder.encodeToString(cipherText);
	}
	/**
	 * Decrypts the <code>encryptedMessage</code> using the private key.
	 * @param encryptedMessage cipher text 
	 * @return the decrypted message
	 * @throws UnsupportedEncodingException if encoding is not UTF-8
	 * @throws InvalidKeyException 
	 * @throws IllegalBlockSizeException
	 * @throws BadPaddingException
	 * @throws InvalidAlgorithmParameterException 
	 */
	String decrypt(final String encryptedMessage) throws UnsupportedEncodingException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException, InvalidAlgorithmParameterException {
		Base64 decoder = new Base64();
		byte[] cipherText = decoder.decode(encryptedMessage);
		byte[] plainText = new byte[cipherText.length];
		cipher.init(Cipher.DECRYPT_MODE, keypair.getPrivate()); //, new SecureRandom());
		plainText = cipher.doFinal(cipherText);
		return new String(plainText, "UTF-8");
	}
	
	/**
	 * Key agreement between two parties; demonstration of the Diffie-Hellman algorithm.
	 * @param algorithm algorithm to use, normally Diffie-Hellman
	 * @param aKeyPair A's key pair
	 * @param bKeyPair B's key pair
	 * @return the shared secret
	 * @throws NoSuchProviderException 
	 * @throws NoSuchAlgorithmException 
	 * @throws InvalidKeyException 
	 */
	String keyAgreement(final String algorithm,final KeyPair aKeyPair, final KeyPair bKeyPair) throws NoSuchAlgorithmException, NoSuchProviderException, InvalidKeyException {
		// set up
        KeyAgreement aKeyAgreement = KeyAgreement.getInstance(algorithm);
        KeyAgreement bKeyAgreement = KeyAgreement.getInstance(algorithm);

        // two party agreement
        aKeyAgreement.init(aKeyPair.getPrivate());
        bKeyAgreement.init(bKeyPair.getPrivate());

        aKeyAgreement.doPhase(bKeyPair.getPublic(), true);
        bKeyAgreement.doPhase(aKeyPair.getPublic(), true);
        
		Base64 encoder = new Base64();
		return encoder.encodeToString(aKeyAgreement.generateSecret()); // or bKeyAgreement.generateSecret(), they are the same
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) throws Exception {
		String message="";
		if (args.length > 0) {
			for (int i=0; i<args.length; i++)
				message += args[i]+" ";
		} else {
			System.out.println("Usage: java -cp .:../lib/commons-codec-1.4.jar gr.ubuntistas.issue10.SimpleASymmetricExample <plain text>");
			System.exit(1);
		}
		System.out.println("Plain text input: " + message);
		
		SimpleASymmetricExample asymmetric = new SimpleASymmetricExample("RSA");  
		
		// encryption pass
		String cipherText = asymmetric.encrypt(message);
		System.out.println("Cipher text: " + cipherText);

		// decryption pass
		System.out.println("Plain text output: " + asymmetric.decrypt(cipherText));
		
		// Diffie-Hellman shared key
		//System.out.println("\nDiffie-Hellman shared key: " + asymmetric.keyAgreement("DiffieHellman", asymmetric.generateKeyPair("DiffieHellman"), asymmetric.generateKeyPair("DiffieHellman")));
	}

}
