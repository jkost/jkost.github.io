package gr.ubuntistas.issue9;

import java.io.UnsupportedEncodingException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.KeyGenerator;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;

import org.apache.commons.codec.binary.Base64;
/**
 * Encrypts and then decrypts a message from the standard input.
 * @author hawk
 *
 */
public class SimpleSymmetricExamplePlus {
	private SecretKey key;  // secret key
	private Cipher cipher;	// cipher being used
	private byte[] iv;		// IV
	
	/**
	 * Initializes the symmetric encryption algorithm
	 * @param algorithm to use, e.g. 'AES', 'DES' etc.
	 * @throws NoSuchAlgorithmException if algorithm does not exist
	 * @throws NoSuchPaddingException
	 */
	SimpleSymmetricExamplePlus(final String algorithm) throws NoSuchAlgorithmException, NoSuchPaddingException {
		key = generateKey(algorithm.indexOf('/') == -1 ? algorithm : algorithm.substring(0, algorithm.indexOf('/')));
		cipher = Cipher.getInstance(algorithm);	
	}
	
	/**
	 * Generates a random secret key.
	 * @param algorithm to use, e.g. DES, AES etc.
	 * @throws NoSuchAlgorithmException if the algorithm string passed as a parameter is not recognized
	 */
	private SecretKey generateKey(final String algorithm) throws NoSuchAlgorithmException {
		KeyGenerator keygen = KeyGenerator.getInstance(algorithm);
		keygen.init(new SecureRandom());
		return keygen.generateKey();
	}
	
	/**
	 * Encrypts the <code>message</code>
	 * @param message plain text message to be encrypted
	 * @return a base64 encoded representation of the encrypted message
	 * @throws UnsupportedEncodingException if encoding is not UTF-8 
	 * @throws InvalidKeyException 
	 * @throws BadPaddingException 
	 * @throws IllegalBlockSizeException 
	 */
	String encrypt(final String message) throws UnsupportedEncodingException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException {
		byte[] plainText = message.getBytes("UTF-8");
		byte[] cipherText = new byte[plainText.length];
		cipher.init(Cipher.ENCRYPT_MODE, key);
		cipherText = cipher.doFinal(plainText);
		iv = cipher.getIV();
		Base64 encoder = new Base64();
		return encoder.encodeToString(cipherText);
	}
	/**
	 * Decrypts the <code>encryptedMessage</code>
	 * @param encryptedMessage cipher text 
	 * @return the decrypted message
	 * @throws UnsupportedEncodingException if encoding is not UTF-8
	 * @throws InvalidKeyException 
	 * @throws IllegalBlockSizeException
	 * @throws BadPaddingException
	 * @throws InvalidAlgorithmParameterException 
	 */
	String decrypt(final String encryptedMessage) throws UnsupportedEncodingException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException, InvalidAlgorithmParameterException {
		Base64 decoder = new Base64();
		byte[] cipherText = decoder.decode(encryptedMessage);
		byte[] plainText = new byte[cipherText.length];
		if (iv != null) {
			cipher.init(Cipher.DECRYPT_MODE, key, new IvParameterSpec(iv));
		} else {
			cipher.init(Cipher.DECRYPT_MODE, key);
		}
		plainText = cipher.doFinal(cipherText);
		return new String(plainText, "UTF-8");
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) throws Exception {
		String message="";
		if (args.length > 0) {
			for (int i=0; i<args.length; i++)
				message += args[i]+" ";
		} else {
			System.out.println("Usage: java -cp .:../lib/commons-codec-1.4.jar gr.ubuntistas.issue8.SimpleSymmetricExample <plain text>");
			System.exit(1);
		}

		System.out.println("Plain text input: " + message);
		
		SimpleSymmetricExamplePlus symmetric = new SimpleSymmetricExamplePlus("PBEWithSHAAnd3KeyTripleDES");
		
		// encryption pass
		String cipherText = symmetric.encrypt(message);
		System.out.println("Cipher text: " + cipherText);

		// decryption pass
		System.out.println("Plain text output: " + symmetric.decrypt(cipherText));
	}

}
